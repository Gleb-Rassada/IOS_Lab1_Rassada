//
//  docLabApp.swift
//  docLab
//
//  Created by user225687 on 11/14/23.
//

import SwiftUI

@main
struct docLabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
