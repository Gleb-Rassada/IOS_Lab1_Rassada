//
//  header.swift
//  docLab
//
//  Created by user225687 on 11/14/23.
//
import SwiftUI

struct headerDoc: View {
    var body: some View {
            HStack(spacing: 197){
                VStack(alignment: .leading,
                       spacing: 6
                ){
                    Text("Hello,")
                        .foregroundColor(Color ("lightGray"))
                    Text("Hi James")
                        .bold()
                }
                Image("frame1")
                    .frame(width: 56, height: 56)
            }
            .padding(.top, 11)
            .padding(.leading, 24)
            .padding(.trailing, 24)
            .padding(.bottom, 32)
    }

}

struct headerDoc_Previews: PreviewProvider {
    static var previews: some View {
        headerDoc()
    }
}
