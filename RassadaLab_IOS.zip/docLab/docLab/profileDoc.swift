//
//  profileDoc.swift
//  docLab
//
//  Created by user225687 on 11/14/23.
//

import SwiftUI

struct profileDoc: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 32){
            VStack(alignment: .leading, spacing: 24){
                VStack(alignment: .leading, spacing: 20){                VStack(alignment: .center, spacing: 16){
                        HStack(alignment: .center) {
                            HStack(alignment: .center, spacing: 12) {
                                ZStack {
                                    Image("circle1")
                                        .frame(width: 48, height: 48)
                                    Rectangle()
                                        .foregroundColor(.clear)
                                        .frame(width: 48, height: 48)
                                        .cornerRadius(1000)
                                        .background(
                                            Image("user")
                                                .resizable()
                                                .aspectRatio(contentMode: .fill)
                                                .frame(width:48, height:48)
                                                .clipShape(Circle())
                                                .clipped()
                                        )
                                }
                                .frame(width: 48, height: 48)
                            
                            VStack(alignment: .leading, spacing: 8){
                                Text("Dr. Imran Syahir")
                                    .font(
                                        Font.custom("Poppins", size: 16)
                                            .weight(.bold)
                                        )
                                    .foregroundColor(.white)
                                Text("General Doctor")
                                  .font(Font.custom("Poppins", size: 14))
                                  .foregroundColor(Color("grey"))
                            }
                            .padding(0)
                            Spacer()
                        }
                        .padding(0)
                        
                        HStack(alignment: .center, spacing: 0){
                            Image("linear")
                                .frame(width: 24, height: 24)
                        }
                        .padding(0)
                        .frame(width: 24, height: 24, alignment: .center)
                    }
                    .padding(0)
                    .frame(maxWidth: .infinity, alignment: .center)
                    
                    Divider()
                        .background(Color.white.opacity(0.15))
                    
                    HStack(alignment: .top, spacing: 12) {
                        HStack(alignment: .center, spacing: 8) {
                            HStack(alignment: .center, spacing: 0) {
                                Image("vuesax/linear/calendar-2")
                                    .frame(width: 16, height: 16)
                            }
                            .padding(0)
                            .frame(width: 16, height: 16, alignment: .center)
                        }
                        .padding(0)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        
                    }
                    .padding(0)
                    .frame(maxWidth: .infinity, alignment: .topLeading)
                }
                .padding(20)
                .frame(width: 327, alignment: .top)
                .background(Color("blue"))
                .cornerRadius(12)
                }
                .padding(0)
            }
            .padding(0)
        }
        .padding(0)
        
    }
}

struct profileDoc_Previews: PreviewProvider {
    static var previews: some View {
        profileDoc()
    }
}
